#Description of project 
This file will include a description of the files in the project folder, including a description of the folder structure. I will also describe the data material, and the scripts. 

In its present version, this README-file can only be seen as a meta-description of what the final version will be, as the actual material is not yet collected. 

## Folder structure
Do not change the structure of the folders.

## Preprocessing
The preprocessing of the data is included and available, but it is not necessary to run the script to run the analysis. Running the preprocessing script will result in an attempt to create a document which already exists in the data folder.

## The material
The data material used in this project is (going to be) collected through a survey. Further description at a later stage. 

 
